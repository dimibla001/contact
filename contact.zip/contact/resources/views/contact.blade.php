
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Контакти</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        form { max-width: 500px; margin: auto; }
        input, textarea { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 5px; }
        button { padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; }
        h2 { text-align: center; }
    </style>
</head>
<body>
<h2>Зв'яжіться з нами</h2>
<form action="#" method="post">
    <input type="text" name="name" placeholder="Ваше ім’я">
    <input type="email" name="email" placeholder="Ваш email">
    <input type="text" name="phone" placeholder="Ваш телефон">
    <textarea name="message" rows="5" placeholder="Ваше повідомлення"></textarea>
    <button type="submit">Відправити</button>
</form>
</body>
</html>
